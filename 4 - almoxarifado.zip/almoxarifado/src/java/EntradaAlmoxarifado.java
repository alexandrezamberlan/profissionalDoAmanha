// Environment code for project almoxarifado

import jason.asSyntax.*;
import jason.environment.*;
import jason.asSyntax.parser.*;

import java.util.Random;
import java.util.logging.*;

public class EntradaAlmoxarifado extends Environment {

    private Logger logger = Logger.getLogger("almoxarifado."+EntradaAlmoxarifado.class.getName());
    String peca;
    Random gerador = new Random();

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        super.init(args);
        try {
        	peca = sorteiaPeca();
        	logger.info("chegou uma " + peca);
			addPercept(ASSyntax.parseLiteral(peca));
		} catch (ParseException e) {
			e.printStackTrace();
		}
    }

    @Override
    public boolean executeAction(String agName, Structure action) {
    	
        if (action.getFunctor().equals("guardarGrande")) { 
        	//animar ou verbalizar ou encaminhar para um microcontrolador
        	logger.info(agName + " está guardando um peça grande");
        } else if (action.getFunctor().equals("guardarMedia")) { 
        	//animar ou verbalizar ou encaminhar para um microcontrolador
        	logger.info(agName + " está guardando um peça média");
        } else if (action.getFunctor().equals("guardarPequena")) { 
        	//animar ou verbalizar ou encaminhar para um microcontrolador
        	logger.info(agName + " está guardando um peça pequena");
        } else if ((action.getFunctor().equals("empilharPeca"))) {
        	logger.info(agName + " peças estao sendo empilhadas na entrada do almoxarifado");
        	
        } else logger.info("tentando executar: "+action+", mas nao foi implementada!!");
        
        try {
			removePercept(ASSyntax.parseLiteral(peca));
			
			//iniciando um novo ciclo
			Thread.sleep(5000);
			peca = sorteiaPeca();
	    	logger.info("chegou uma " + peca);
			addPercept(ASSyntax.parseLiteral(peca));
			
			
			//simular um carregamento de bateria
			if (gerador.nextInt(5) == 0) {
				addPercept(ASSyntax.parseLiteral("bateria(carregada)"));
			}
			
			
			
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TokenMgrError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
        
        
        return true; // the action was executed with success
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
    
    private String sorteiaPeca() {
    	
    	switch (gerador.nextInt(3)) {
	    	case 0:
	    		return "peca(grande)";
	    	case 1:
	    		return "peca(media)";
	    	case 2:
	    		return "peca(pequena)";
	    	default:
	    		return "";
    	}
    }

}
